
let abrirCadastro = document.getElementById("botaoAbrirCadastro");

abrirCadastro.onclick = function(){
    document.getElementById('botaoFecharLogin').click();
}