
jQuery(window).load(function() {
	jQuery("#loading").fadeOut(500);
});
