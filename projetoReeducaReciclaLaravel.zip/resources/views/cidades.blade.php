<?php

echo json_encode($cidades);
