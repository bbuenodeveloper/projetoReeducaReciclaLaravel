


@foreach($adminLista as $admin)
{{$admin->name}}
@endforeach
