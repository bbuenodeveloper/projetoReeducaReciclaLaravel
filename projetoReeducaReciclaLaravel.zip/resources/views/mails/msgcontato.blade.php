<div>
    Olá administrador!<br>
    <br>
    O contato {{ $name }} ({{ $email }}) enviou a seguinte mensagem:<br>
    <br>
    <br>
    <hr>
    <i>
        {{ $msg }}
    </i>
    <hr>
</div>  