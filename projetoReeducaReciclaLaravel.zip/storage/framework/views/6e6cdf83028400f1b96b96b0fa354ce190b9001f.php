<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-4 ">
<h1 class="titulo-painel">ADMINISTRADOR</h1>
            <div>
<span class="color-title sub-titulo-painel">RECICLA MAPS</span></h1></div>
        </div>
        <div class="col-md-8 ">
            <img src="<?php echo e(asset('img/painelimagem.png')); ?>" alt=""  class="float-right" width="70%">
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appPainel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetoReeducaReciclaLaravel\resources\views/painel.blade.php ENDPATH**/ ?>