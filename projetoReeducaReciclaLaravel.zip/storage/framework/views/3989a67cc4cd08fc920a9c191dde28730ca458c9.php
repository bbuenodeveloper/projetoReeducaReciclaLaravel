<?php $__env->startSection('content'); ?>
<div class="container p-4">
    <div class="row justify-content-center">
        <div class="jumbotron col-md-8 border rounded border-success">
        <div class="col-md-12">
            <form method="POST" action="<?php echo e(route('register')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="col-md-12 container  p-4 text-center">
                <div class="logoRegister mb-4">
                        <a href="index.html">
                            <img class="logoRegister mb-3" src="<?php echo e(asset('img/logologin.png')); ?>" alt>
                        </a>
                    <div>
                    <div class="form-group row">

                        <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nome')); ?></label>

                        <div class="col-md-6">
                            <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="sobrenome" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Sobrenome')); ?></label>

                        <div class="col-md-6">
                            <input id="sobrenome" type="text" class="form-control <?php if ($errors->has('sobrenome')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sobrenome'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="sobrenome" value="<?php echo e(old('sobrenome')); ?>" required autocomplete="sobrenome" autofocus>

                            <?php if ($errors->has('sobrenome')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sobrenome'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail')); ?></label>

                        <div class="col-md-6">
                            <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="data_nascimento" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Data de Nascimento')); ?></label>

                        <div class="col-md-6">
                            <input id="data_nascimento" type="date" class="form-control <?php if ($errors->has('data_nascimento')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('data_nascimento'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="data_nascimento" value="<?php echo e(old('data_nascimento')); ?>" required autocomplete="data_nascimento" style="font-style:italic">

                            <?php if ($errors->has('data_nascimento')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('data_nascimento'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="telefone" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Telefone')); ?></label>

                        <div class="col-md-6">
                            <input id="telefone" type="number" class="form-control <?php if ($errors->has('telefone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telefone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="telefone" value="<?php echo e(old('telefone')); ?>" required autocomplete="telefone" mask="(__) _____-____" placeholder="Ex: (xx) xxxx-xxxx"style="font-style:italic">

                            <?php if ($errors->has('telefone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telefone'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Senha')); ?></label>

                        <div class="col-md-6">
                            <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">

                            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirmar Senha')); ?></label>

                        <div class="col-md-6">
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="cep" class="col-md-4 col-form-label text-md-right"><?php echo e(__('CEP')); ?></label>

                        <div class="col-md-6">
                            <input id="cep" type="text" class="form-control <?php if ($errors->has('cep')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('cep'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="cep" required autocomplete="cep" mask="_____-___" placeholder="Ex: xxxxx-xxx" style="font-style:italic">

                            <?php if ($errors->has('cep')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('cep'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="endereco" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Endereço')); ?></label>

                        <div class="col-md-6">
                            <input id="endereco" type="text" class="form-control <?php if ($errors->has('endereco')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('endereco'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="endereco" required autocomplete="endereco">

                            <?php if ($errors->has('endereco')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('endereco'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="numero" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Número')); ?></label>

                        <div class="col-md-6">
                            <input id="numero" type="text" class="form-control <?php if ($errors->has('numero')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('numero'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="numero" required autocomplete="numero">

                            <?php if ($errors->has('numero')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('numero'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="complemento" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Complemento')); ?></label>

                        <div class="col-md-6">
                            <input id="complemento" type="text" class="form-control <?php if ($errors->has('complemento')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('complemento'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="complemento" required autocomplete="complemento">

                            <?php if ($errors->has('complemento')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('complemento'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="bairro" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Bairro')); ?></label>

                        <div class="col-md-6">
                            <input id="bairro" type="text" class="form-control <?php if ($errors->has('bairro')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bairro'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="bairro" required autocomplete="bairro">

                            <?php if ($errors->has('bairro')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bairro'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="estado" class="col-md-4 col-form-label text-md-right"><?php echo e(_('Estado')); ?></label>
                        <div class="col-md-6">
                            <select id="estado" type="text" class="form-control <?php if ($errors->has('estado')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('estado'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="estado" required autocomplete="estado">
                            <option selected>Selecione</option>
                            <option>São Paulo</option>
                            </select>
                            <?php if ($errors->has('estado')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('estado'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="cidade" class="col-md-4 col-form-label text-md-right"><?php echo e(_('Cidade')); ?></label>
                        <div class="col-md-6">
                            <select id="cidade" type="text" class="form-control <?php if ($errors->has('cidade')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('cidade'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="cidade" required autocomplete="cidade">
                            <option selected>Selecione</option>
                            <option>São Paulo</option>
                            </select>
                            <?php if ($errors->has('cidade')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('cidade'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label style="display:none" for="nivelUser" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nivel usuário')); ?></label>
                        <div class="col-md-6">
                            <input id="name" type="hidden" class="form-control ">
                        </div>
                    </div>
                    <div class="form-group row">
                            <label for="avatar" class="col-md-4 col-form-label text-md-right">Insira sua foto</label>
                            <div class="col-md-6">
                                <input type="file" name="avatar" id="avatar" accept="image/png,image/jpg">
                            </div>
                        </div>

                    <div class="form-group row mb-0">
                        <div class="col-md-6 offset-md-4">
                            <button type="submit" class="btn btn-primary float-right">
                                <?php echo e(__('Cadastrar')); ?>

                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetoReeducaReciclaLaravel\resources\views/registerPainel.blade.php ENDPATH**/ ?>