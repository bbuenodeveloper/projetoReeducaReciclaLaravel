<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
    <table class="table table-hover table-striped table-bordered table-sm">
      <thead class="thead-dark">
        <tr>
          <th>Id</th>
          <th>cidade</th>
          <th>Imagem</th>
          <th>Editar</th>
          <th>Apagar</th>
        </tr>
      </thead>
      <tbody>

          <?php $__currentLoopData = $cidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($cidade->id); ?></td>
            <td><?php echo e($cidade->cidade); ?></td>
            <td><?php echo e($cidade->imagem); ?></td>
            <td><a href="/editar-cidade/<?php echo e($cidade->id); ?>"><button class="btn btn-success" >Editar</button></a></td>
            <td><button class="btn btn-danger" id="deletaCidade" onclick="deletaCidade(<?php echo e($cidade->id); ?>)">Apagar</button></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </tbody>
    </table>

        </div>
    </div>
    <?php echo e($cidades->links()); ?>

  </div>


  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appPainel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetoReeducaReciclaLaravel\resources\views/relatorio-Cidades.blade.php ENDPATH**/ ?>