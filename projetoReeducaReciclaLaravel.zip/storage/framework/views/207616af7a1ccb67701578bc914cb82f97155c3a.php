<?php $__env->startSection('content'); ?>

<div class="container-fluid dataTables_wrapper dt-bootstrap4" id="dtBasicExample_wrapper">
    <div class="row">
        <div class="col-12">
    <table id="align-table" class="table table-hover table-sm table-striped table-bordered table-sm ">
      <thead class="thead-light">
        <tr>
          <th class="th-sm">Id</th>
          <th class="th-sm">Nome</th>
          <th>Endereço</th>
          <th>Numero</th>
          <th>Complemento</th>
          <th>Cep</th>
          <th>Bairro</th>
          <th>Estado</th>
          <th>Telefone</th>
          <th>Site</th>
          <th>Latitude</th>
          <th>longitude</th>
          <th>Editar</th>
          <th>Apagar</th>


        </tr>
      </thead>
      <tbody>

          <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($empresa->id); ?></td>
            <td><?php echo e($empresa->nome); ?></td>
            <td><?php echo e($empresa->endereco); ?></td>
            <td><?php echo e($empresa->numero); ?></td>
            <td><?php echo e($empresa->complemento); ?></td>
            <td><?php echo e($empresa->cep); ?></td>
            <td><?php echo e($empresa->bairro); ?></td>
            <td><?php echo e($empresa->estado); ?></td>
            <td><?php echo e($empresa->telefone); ?></td>
            <td><?php echo e($empresa->site); ?></td>
            <td><?php echo e($empresa->latitude); ?></td>
            <td><?php echo e($empresa->longitude); ?></td>
            <td><a href="/editar-empresa/<?php echo e($empresa->id); ?>"><button class="btn btn-success" >Editar</button></a></td>
            <td><button class="btn btn-danger" id="deletaEmpresa" onclick="deletaEmpresa(<?php echo e($empresa->id); ?>)">Apagar</button></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </tbody>
    </table>

        </div>
    </div>
    <?php echo e($empresas->links()); ?>

  </div>




  <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.appPainel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetoReeducaReciclaLaravel\resources\views/relatorio-Empresas.blade.php ENDPATH**/ ?>