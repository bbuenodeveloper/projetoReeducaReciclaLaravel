<?php $__env->startSection('content'); ?>


<?php
$root = 'http://www.reciclamaps.com.br';
$foto = 'mapahome.png';
$title = $facebook_title = "Loja";
$keywords = 'reciclamaps,reciclagem, reciclar, doar, descarte, consumo, consciente, descartar, como, descartar, Construção e Demolição, Diversos, Eletrodomésticos, Eletrônicos, Embalagens longa vida, Lâmpadas, Líquidos e Produtos Químicos, Materiais Orgânicos, Metais, Móveis, Óleos, Papel e Papelão, Pilhas e Baterias, Plástico, Veículos, Vestuário, Vidro';
$description = $facebook_description = substr(strip_tags('<p>Você pode ajudar o meio ambiente com uma ação muito simples. O mapa interativo do ReciclaMaps mostra os pontos de coleta mais próximos a você.</p>'), 0, 200);
$facebook_image = htmlentities($root . 'img/' . $foto);?>

<div class="bg-light py-3">
    <div class="container">
        <div class="row">
            <div class="col-6"><a href="/home">Home</a> <span class="mx-2 mb-0">/</span> <strong
                    class="text-black">Loja</strong></div>
            <div class="col-6"><a href="/carrinho"><img src="<?php echo e(asset('img/produtos_loja/carrinho.png')); ?>"
                        class="sizeCarrinho pull-right" alt=""></a>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-12 mt-5 mb-3">
            <nav class="nav ">
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="nav-link fonteCateg" href="#"><?php echo e($categoria->nome_categoria); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </nav>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-4 mb-5">
            <figure class="card card-product">
                <div class="img-wrap"><a href="/internaProduto/<?php echo e($produto->id); ?>"><img
                            src="/storage/produtos/<?php echo e($produto->imagem); ?>"></a></div>
                <figcaption class="info-wrap">
                    <h4 class="title"><?php echo e($produto->nome); ?></h4>
                </figcaption>
                <div class="bottom-wrap">
                    <a href="/internaProduto/<?php echo e($produto->id); ?>" class="btn btn-sm btn-primary float-right">COMPRAR</a>
                    <div class="price-wrap h5">
                        <span class="price-new">R$<?php echo e($produto->preco); ?></span>
                    </div> <!-- price-wrap.// -->
                </div> <!-- bottom-wrap.// -->
            </figure>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- col // -->
    </div>
    <!-- row.// -->
</div>
<div class="container">
    <div class="row">
        <div class="col-12 d-flex justify-content-center">
            <center>
                <?php echo e($produtos->links()); ?>

            </center>
        </div>
    </div>
</div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetoReeducaReciclaLaravel\resources\views/loja.blade.php ENDPATH**/ ?>