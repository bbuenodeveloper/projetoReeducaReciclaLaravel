<div>
    Olá administrador!<br>
    <br>
    O contato <?php echo e($name); ?> (<?php echo e($email); ?>) enviou a seguinte mensagem:<br>
    <br>
    <br>
    <hr>
    <i>
        <?php echo e($msg); ?>

    </i>
    <hr>
</div>  <?php /**PATH C:\xampp\htdocs\projetoReeducaReciclaLaravel\resources\views/mails/msgcontato.blade.php ENDPATH**/ ?>