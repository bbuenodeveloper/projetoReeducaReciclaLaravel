<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, user-scalable=yes">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="theme-color" content="#000000">
        <link rel="icon" href="img/favicon.png" sizes="16x16 32x32" type="image/jpg">

        <!-- Metas para o Google -->
        <title><?php @print($title); ?></title>
        <meta name="description" content="<?php @print($description); ?>">
        <meta name="keywords" content="<?php @print($keywords); ?>">

        <!-- Metas para o Facebook -->
        <meta property="og:type" content="website" />
        <meta property="og:title" content="<?php @print($facebook_title); ?>" />
        <meta property="og:url" content="<?php @print($facebook_url); ?>" />
        <meta property="og:site_name" content="<?php @print($facebook_site_name); ?>" />
        <meta property="og:description" content="<?php @print($facebook_description); ?>" />
        <meta property="og:image" content="<?php @print($facebook_image); ?>" />
        <?php if (!empty($facebook_image_width)): ?>
        <meta property="og:image:width" content="<?php @print($facebook_image_width); ?>" /><?php endif ?>
        <?php if (!empty($facebook_image_height)): ?>
        <meta property="og:image:height" content="<?php @print($facebook_image_height); ?>" /><?php endif ?>
        <meta property="fb:app_id" content="501123709922257" />

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


        <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/recicla-guide.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/dropdown.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/jquery.fancybox.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/stylesa361.css?ver=2.3')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/beta-popup.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/font-awesome.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/ionicons.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/chartist.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/rickshaw.min.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('css/slim.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
        <link href="<?php echo e(asset('css/mdb.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/mdb.lite.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/addons/datatables.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/addons/datatables-select.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/ckeditor/editor.css')); ?>" rel="stylesheet">

        <title>Painel</title>


    </head>


    <?php if (false): ?>
    <?php endif ?>
    <div id="app">




    <div class="slim-header">
        <div class="container">
          <div class="slim-header-left">
            <a href="\painel"><img src="img/logo_lado.png" class="logoMargin logoSize"alt=""></a>
          </div>
          <!-- slim-header-left -->
          <div class="slim-header-right">
            <div class="dropdown dropdown-c">
              <a href="#" class="logged-user" data-toggle="dropdown">
                <img src="http://via.placeholder.com/500x500" alt="">
                <span> <?php echo e(Auth::user()->name); ?></span>
                <i class="fa fa-angle-down"></i>
              </a>
              <div class="dropdown-menu dropdown-menu-right">
                <nav class="nav">
                  <a href="#" class="nav-link"><i class="fa fa-user"></i><span class="space-menu">Ver Perfil</span></a>
                  <a href="#" class="nav-link"><i class="fa fa-edit"></i><span class="space-menu">Editar Perfil</span></a>
                  <a href="#" class="nav-link"><i class="fa fa-cog"></i><span class="space-menu">Configurações</span></a>
                  <a href="/home" class="nav-link"><i class="fa fa-sign-out"></i><span class="space-menu">Sair</span></a>
                </nav>
              </div><!-- dropdown-menu -->
            </div><!-- dropdown -->
          </div><!-- header-right -->
        </div><!-- container -->
      </div><!-- slim-header -->

      <div class="slim-navbar">
        <div class="container">
          <ul class="nav">
            <li class="nav-item with-sub">
              <a class="nav-link" href="#">
                <i class="fas fa-user-circle"></i>
                <span class="space-menu">Usuários</span>
              </a>
              <div class="sub-item">
                <ul>
                  <li><a href="/registerPainel">Cadastro de Usuários</a></li>
                  <li><a href="/add-admin">Cadastro de Admin</a></li>
                  <li class="sub-with-sub">
                    <a href="#">Relatorios</a>
                    <ul>
                      <li><a href="/relatorio-Users">Relatorio de Usuários</a></li>
                      <li><a href="/relatorio-Admins">Relatorio de Admins</a></li>

                    </ul>
                  </li>

                </ul>
              </div>
            </li>
            <li class="nav-item with-sub">
              <a class="nav-link" href="#">
                <i class="fas fa-map"></i>
                <span class="space-menu">Mapa</span>
              </a>
              <div class="sub-item">
                <ul>
                  <li><a href="/add-empresa">Cadastro de Empresas</a></li>
                  <li><a href="/add-cidade">Cadastro de Cidades</a></li>
                  <li><a href="/add-material">Cadastro de Materiais</a></li>
                  <li class="sub-with-sub">
                    <a href="#">Relatorios</a>
                    <ul>
                      <li><a href="/relatorio-Empresas">Relatorio de Empresas</a></li>
                      <li><a href="/relatorio-Cidades">Relatorio de Cidades</a></li>
                      <li><a href="/relatorio-Materiais">Relatorio de Materiais</a></li>
                    </ul>
                  </li>

                </ul>
              </div>
            </li>
            <li class="nav-item with-sub">
              <a class="nav-link" href="#">
                <i class="fas fa-store"></i>
                <span class="space-menu">Loja</span>
              </a>
              <div class="sub-item">
                <ul>
                  <li><a href="/add-produto">Cadastro de Produtos</a></li>
                  <li><a href="/add-categoria">Cadastro de Categorias</a></li>
                  <li><a href="/add-pagamento">Forma de Pagamento</a></li>
                  <li class="sub-with-sub">
                    <a href="#">Relatorios</a>
                    <ul>
                      <li><a href="/relatorio-Produtos">Relatorio de Produtos</a></li>
                      <li><a href="/relatorio-Categorias">Relatorio de Categorias</a></li>
                      <li><a href="#">Relatorio de Forma de Pagamento</a></li>
                    </ul>
                  </li>

                </ul>
              </div>
            </li>
            <li class="nav-item with-sub">
              <a class="nav-link" href="#">
                <i class="fas fa-newspaper-o"></i>
                <span class="space-menu">Newsletter</span>
              </a>
              <div class="sub-item">
                <ul>
                  <li><a href="/add-newsletter">Cadastro de Assinantes</a></li>
                  <li class="sub-with-sub">
                    <a href="#">Relatorios</a>
                    <ul>
                      <li><a href="/relatorio-Newsletter">Relatorio de Assinantes</a></li>

                    </ul>
                  </li>

                </ul>
              </div>
            </li>
            <li class="nav-item with-sub">
              <a class="nav-link" href="#">
                <i class="fas fa-blog"></i>
                <span class="space-menu">Blog</span>
              </a>
              <div class="sub-item">
                <ul>
                  <li><a href="/add-postagens">Cadastro de Postagens</a></li>
                  <li class="sub-with-sub">
                    <a href="#">Relatorios</a>
                    <ul>
                      <li><a href="/relatorio-Posts">Relatorio de Postagens</a></li>
                    </ul>
                  </li>
                </ul>
              </div>
            </li>
          </ul>
        </div><!-- container -->
      </div><!-- slim-navbar -->

      <div>
        <div class="container">
          <div class="slim-pageheader">
            <ol class="breadcrumb slim-breadcrumb">
              <li class="breadcrumb-item"><a href="/home">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Painel</li>
            </ol>
            <h6 class="slim-pagetitle">Painel</h6>
          </div>
        </div><!-- row -->
      <!-- container -->
    </div>






    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>


    <!-- footer -->

  <div class="slim-footer">
    <div class="container">
      <p>Copyright 2019 &copy; Recicla Maps - Todos os Direitos Reservados.</p>
      <p>Produzido Por: <a href="#">Recicla Maps</a></p>
    </div>
  </div>
<!-- footer -->







        <link rel="stylesheet" href="<?php echo e(asset('sweetalert/dist/sweetalert2.min.css')); ?>">

        <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"
          integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
          crossorigin="anonymous"></script>
        <script src="https://cdn.ckeditor.com/4.4.5.1/basic/ckeditor.js"></script>
        <script src="<?php echo e(asset('js/ajaxDeletapostagem.js')); ?>"></script>
        <script src="<?php echo e(asset('js/ajaxDeletaCidade.js')); ?>"></script>
        <script src="<?php echo e(asset('js/ajaxDeletaEmpresa.js')); ?>"></script>
        <script src="<?php echo e(asset('js/ajaxDeletaMaterial.js')); ?>"></script>
        <script src="<?php echo e(asset('js/ajaxDeletaNews.js')); ?>"></script>
        <script src="<?php echo e(asset('sweetalert/dist/sweetalert2.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/alertSweetRecicla.js')); ?>"></script>
        <script src="<?php echo e(asset('js/ajaxValidaPostagem.js')); ?>"></script>
        <script src="<?php echo e(asset('js/ajaxValidaEmpresa.js')); ?>"></script>
        <script src="<?php echo e(asset('js/ajaxValidaCidade.js')); ?>"></script>
        <script src="<?php echo e(asset('js/ajaxValidaMaterial.js')); ?>"></script>
        <script src="<?php echo e(asset('js/alertSweetRecicla.js')); ?>"></script>
        <script src="<?php echo e(asset('js/postNewsletterAdmin.js')); ?>"></script>
        
        <script src="<?php echo e(asset('js/ckeditor/editor-ck-init.js')); ?>"></script>
        <script src="<?php echo e(asset('js/ckeditor/plugin.js')); ?>"></script>
        <script src="<?php echo e(asset('js/ckeditor/ckeditor.js')); ?>"></script>
        <script src="https://kit.fontawesome.com/edcfdf1ead.js"></script>
        <script src="http://malsup.github.com/jquery.form.js"></script>
        <script src="<?php echo e(asset('js/gmaps.js')); ?>"></script> <!-- plugin para google maps api -->
        <script src="<?php echo e(asset('js/recicla.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/popper.js')); ?>"></script>
        <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/mdb.js')); ?>"></script>
        <script src="<?php echo e(asset('js/addons/datatables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/addons/datatables-select.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/postCadastroAdmin.js')); ?>"></script>

<?php /**PATH C:\xampp\htdocs\projetoReeducaReciclaLaravel\resources\views/layouts/appPainel.blade.php ENDPATH**/ ?>