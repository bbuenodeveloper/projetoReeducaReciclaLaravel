<?php $__env->startSection('content'); ?>

<div class="container-fluid dataTables_wrapper dt-bootstrap4" id="dtBasicExample_wrapper">
    <div class="row">
        <div class="col-12">
    <table id="align-table" class="table table-hover table-sm table-striped table-bordered table-sm ">
      <thead class="thead-light">
        <tr>
          <th class="th-sm">Id</th>
          <th class="th-sm">Nome</th>
          <th>Imagem</th>
          <th>Preço</th>
          <th>Descrição</th>
          <th>Estoque</th>
          <th>Editar</th>
          <th>Apagar</th>


        </tr>
      </thead>
      <tbody>

          <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($produto->id); ?></td>
            <td><?php echo e($produto->nome); ?></td>
            <td><?php echo e($produto->imagem); ?></td>
            <td><?php echo e($produto->preco); ?></td>
            <td><?php echo e($produto->descricao); ?></td>
            <td><?php echo e($produto->quantidade_estoque); ?></td>
            <td><a href="/editar-produto/<?php echo e($produto->id); ?>"><button class="btn btn-success" >Editar</button></a></td>
            <td><button class="btn btn-danger" id="deletaProduto" onclick="deletaEmpresa(<?php echo e($produto->id); ?>)">Apagar</button></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </tbody>
    </table>

        </div>
    </div>
    <?php echo e($produtos->links()); ?>

  </div>




  <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.appPainel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetoReeducaReciclaLaravel\resources\views/relatorio-Produtos.blade.php ENDPATH**/ ?>