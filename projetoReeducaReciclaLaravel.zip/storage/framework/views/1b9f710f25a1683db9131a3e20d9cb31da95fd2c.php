<?php $__env->startSection('content'); ?>



<div class="container">
    <div class="row">
        <div class="col-6 mx-auto m-5">
<div class="jumbotron">
    <h1 class="text-center mb-2">Cadastro de Administrador</h1>
    <form action="<?php echo e(route('admin.cadastrar')); ?>" method="post" class="user-info-setting-form" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Nome</label>
            <input type="text" name="name" class="form-control" placeholder="Nome do admin">
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" name="email" class="form-control" placeholder="Email do admin">
        </div>
            <div class="form-group">
            <label for="password">Senha</label>
            <input type="password" name="password" class="form-control" placeholder="Senha">
        </div>

        <div class="form-group">
            <label for="password-confirm">Confirmar Senha</label>
            <input type="password" name="password-confirm" class="form-control" placeholder="Confirmar Senha">
        </div>

        <button type="submit" class="btn btn-card btn-primary">CADASTRAR</button>
    </form>
</div>
</div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appPainel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetoReeducaReciclaLaravel\resources\views/add-admin.blade.php ENDPATH**/ ?>