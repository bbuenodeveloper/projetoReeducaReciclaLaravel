<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
    <table class="table table-hover table-striped table-bordered table-sm">
      <thead class="thead-dark">
        <tr>
          <th>Id</th>
          <th>Materiais</th>
          <th>Editar</th>
          <th>Apagar</th>
        </tr>
      </thead>
      <tbody>

          <?php $__currentLoopData = $materiais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($material->id); ?></td>
            <td><?php echo e($material->tipoMaterial); ?></td>
            <td><a href="/editar-material/<?php echo e($material->id); ?>"><button class="btn btn-success" >Editar</button></a></td>
            <td><button class="btn btn-danger" id="deletaMaterial" onclick="deletaMaterial(<?php echo e($material->id); ?>)">Apagar</button></td>

            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </tbody>
    </table>

        </div>
    </div>
    <?php echo e($materiais->links()); ?>

  </div>




  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appPainel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetoReeducaReciclaLaravel\resources\views/relatorio-Materiais.blade.php ENDPATH**/ ?>